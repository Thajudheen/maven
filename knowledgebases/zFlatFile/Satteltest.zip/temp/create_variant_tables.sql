drop table X_LAENDERTAB_10
/
create table X_LAENDERTAB_10
(
M_PSEG char(05) not null,
X_LAND1 char(03) not null,
X_VKOND_ART char(01) not null,
X_SPRAS char(01) not null
)
/
drop table S_ACHSABSTAND_10
/
create table S_ACHSABSTAND_10
(
S_VERKAUF char(30) not null,
SZAXX char(05) not null,
SFWXX char(05) not null,
SZMXX char(05) not null,
SADXX char(05) not null,
S_TYP char(04) not null
)
/
drop table S_ACHS_VK2_10
/
create table S_ACHS_VK2_10
(
SAGXX char(05) not null,
SAMXX char(05) not null,
SBRXX char(05) not null,
SARXX char(05) not null,
SALXX char(05) not null,
SANXX char(05) not null,
SLAXX char(05) not null,
SAWXX char(05) not null,
MRBXX char(05) not null,
S_FAHRHO char(08) not null
)
/
drop table S_ACHS_VK2_43_10
/
create table S_ACHS_VK2_43_10
(
SAGXX char(05) not null,
SBRXX char(05) not null,
SARXX char(05) not null,
SALXX char(05) not null,
SANXX char(05) not null,
SLAXX char(05) not null,
SAWXX char(05) not null,
MRBXX char(05) not null,
S_FAHRHO char(08) not null
)
/
drop table S_AUFSATTELH_VK2_10
/
create table S_AUFSATTELH_VK2_10
(
S_VERKAUF char(30) not null,
SZAXX char(05) not null,
SZMXX char(05) not null,
X_TEXT_NUM double precision not null,
X_TEXT_NUM1 double precision not null
)
/
drop table S_AUSWAHL_STUELIS_10
/
create table S_AUSWAHL_STUELIS_10
(
S_BEWERTUNG char(01) not null,
X_MATN1 char(18) not null
)
/
drop table S_FWR_KB_AUSWAHL_10
/
create table S_FWR_KB_AUSWAHL_10
(
S_BEWERTUNG char(01) not null,
S_TYP char(04) not null,
X_MATN1 char(18) not null
)
/
drop table S_AUSWAHL_KB_43_10
/
create table S_AUSWAHL_KB_43_10
(
S_BEWERTUNG char(01) not null,
S_TYP char(04) not null,
X_MATN1 char(18) not null
)
/
drop table S_AUSWAHL_ZUBEHOER_10
/
create table S_AUSWAHL_ZUBEHOER_10
(
S_BEWERTUNG char(01) not null,
X_MATN1 char(18) not null
)
/
drop table S_ST_FAHRHO_10
/
create table S_ST_FAHRHO_10
(
SBRXX char(05) not null,
S_FAHRHO char(08) not null,
X_STAND7 char(02) not null,
X_STAND9 char(02) not null,
X_STAND13 char(01) not null
)
/
drop table S_FARBE_PLANE_43_10
/
create table S_FARBE_PLANE_43_10
(
SPLXX char(05) not null,
SMPXX char(05) not null,
SFPXX char(05) not null
)
/
drop table S_KB_VK2_43_10
/
create table S_KB_VK2_43_10
(
S_TYP char(04) not null,
SBFXX char(05) not null,
SHFXX char(05) not null,
S_NLAENGE double precision not null,
S_BREITE double precision not null,
S_HOEHE double precision not null,
SBMXX char(05) not null,
SSMXX char(05) not null,
SVMXX char(05) not null,
SHMXX char(05) not null
)
/
drop table S_LAENGE_KB_10
/
create table S_LAENGE_KB_10
(
S_NLAENGE double precision not null,
X_STAND10 char(07) not null
)
/
drop table S_KF_VAR_VK2_10
/
create table S_KF_VAR_VK2_10
(
S_TYP char(04) not null,
SKFXX char(05) not null,
SFMXX char(05) not null,
SBSXX char(05) not null,
SKTXX char(05) not null
)
/
drop table S_KB_VK2_10
/
create table S_KB_VK2_10
(
S_TYP char(04) not null,
SBFXX char(05) not null,
SHFXX char(05) not null,
S_NLAENGE double precision not null,
S_BREITE double precision not null,
S_HOEHE double precision not null,
SBMXX char(05) not null,
SSMXX char(05) not null,
SVMXX char(05) not null,
SHMXX char(05) not null
)
/
drop table S_LEIT_PLANE_DACH_10
/
create table S_LEIT_PLANE_DACH_10
(
S_TYP char(04) not null,
SKSXX char(05) not null,
SLEXX char(05) not null,
SKLXX char(05) not null,
SKBXX char(05) not null,
SERXX char(05) not null,
SEHXX char(05) not null,
SPVXX char(05) not null
)
/
drop table S_LIFT_POS_VK2_10
/
create table S_LIFT_POS_VK2_10
(
SAWXX char(05) not null,
SLAXX char(05) not null,
SHVXX char(05) not null
)
/
drop table S_PLANENSYST_VK2_10
/
create table S_PLANENSYST_VK2_10
(
S_NLAENGE double precision not null,
SHFXX char(05) not null,
SRLXX char(05) not null,
SPVXX char(05) not null,
SPLXX char(05) not null,
SMPXX char(05) not null
)
/
drop table S_PLANE_EINSCHR_43_10
/
create table S_PLANE_EINSCHR_43_10
(
SPVXX char(05) not null,
SBFXX char(05) not null,
S_HOEHE double precision not null,
SRLXX char(05) not null,
SHFXX char(05) not null,
SKSXX char(05) not null
)
/
drop table S_PLA_SYST_VK2_43_10
/
create table S_PLA_SYST_VK2_43_10
(
S_NLAENGE double precision not null,
SHFXX char(05) not null,
SRLXX char(05) not null,
SPVXX char(05) not null,
SPLXX char(05) not null,
SMPXX char(05) not null
)
/
drop table S_PLANE_NR_VK2_10
/
create table S_PLANE_NR_VK2_10
(
S_NLAENGE double precision not null,
SHFXX char(05) not null,
SRLXX char(05) not null,
SPLXX char(05) not null,
SNPXX char(05) not null,
X_MATNU char(18) not null,
X_MATN1 char(18) not null
)
/
drop table S_PRODH2_10
/
create table S_PRODH2_10
(
X_HANDELSB char(04) not null,
X_ZZPRODH char(18) not null
)
/
drop table S_BEZ_GEW_10
/
create table S_BEZ_GEW_10
(
S_VERKAUF char(30) not null,
SZAXX char(05) not null,
SGWXX char(05) not null,
X_MATN1 char(18) not null
)
/
drop table S_RAEDER_VK2_10
/
create table S_RAEDER_VK2_10
(
SAGXX char(05) not null,
MRFXX char(05) not null,
MRGXX char(05) not null,
SANXX char(05) not null,
MRBXX char(05) not null,
MRMXX char(05) not null,
X_MATNU char(18) not null
)
/
drop table S_FWR_WERTE_VK2_10
/
create table S_FWR_WERTE_VK2_10
(
S_TYP char(04) not null,
SBRXX char(05) not null,
SBFXX char(05) not null,
X_FWRLAEN double precision not null,
X_RHOEHE double precision not null,
SFEXX char(05) not null,
SAGXX char(05) not null,
MRGXX char(05) not null,
SKZXX char(05) not null,
SHVXX char(05) not null
)
/
drop table S_R_WERTE_VK2_43_10
/
create table S_R_WERTE_VK2_43_10
(
S_TYP char(04) not null,
SBRXX char(05) not null,
X_FWRLAEN double precision not null,
SFWXX char(05) not null,
X_RHOEHE double precision not null,
SFEXX char(05) not null,
SAGXX char(05) not null,
MRGXX char(05) not null,
SKZXX char(05) not null,
SHVXX char(05) not null
)
/
drop table S_TYP_BEST_10
/
create table S_TYP_BEST_10
(
S_VERKAUF char(30) not null,
SBFXX char(05) not null,
SKMXX char(05) not null,
S_PGRP char(04) not null,
SZAXX char(05) not null,
S_VERKAUFSB char(30) not null,
SHFXX char(05) not null,
S_HANDELSB char(04) not null,
X_STAND11 char(05) not null,
X_STAND12 char(05) not null,
S_TYP char(04) not null
)
/
drop table S_VERK_BEZ_10
/
create table S_VERK_BEZ_10
(
S_VERKAUFSB char(30) not null,
S_HOEHE double precision not null,
S_KVOLUMEN double precision not null
)
/
drop table S_VOL_KB_VK2_10
/
create table S_VOL_KB_VK2_10
(
S_TYP char(04) not null,
S_NLAENGE double precision not null,
S_HOEHE double precision not null,
S_KVOLUMEN double precision not null
)
/
drop table S_LEIT_PL_DACH_43_10
/
create table S_LEIT_PL_DACH_43_10
(
S_TYP char(04) not null,
SKSXX char(05) not null,
SKLXX char(05) not null,
SKBXX char(05) not null,
SESXX char(05) not null,
SPVXX char(05) not null
)
/
drop table S_EINSCHR_EB3_43_10
/
create table S_EINSCHR_EB3_43_10
(
SBFXX char(05) not null,
SVKXX char(05) not null,
SEKXX char(05) not null,
SSLXX char(05) not null,
SZAXX char(05) not null
)
/
drop table S_W_KISTE_VK2_10
/
create table S_W_KISTE_VK2_10
(
S_VERKAUF char(30) not null,
SBFXX char(05) not null,
SZAXX char(05) not null,
SKFXX char(05) not null,
SWKXX char(05) not null,
X_MATN1 char(18) not null
)
/
